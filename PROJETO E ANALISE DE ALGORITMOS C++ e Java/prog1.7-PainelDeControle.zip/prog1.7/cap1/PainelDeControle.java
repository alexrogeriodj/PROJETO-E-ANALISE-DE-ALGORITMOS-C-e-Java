package cap1;
class PainelDeControle {
  private float temperaturaCorrente;
  private float temperaturaDesejada;

  public void ligaForno () {
    // @{\it c\'odigo do m\'etodo}@
  }
  public void desligaForno() {
    // @{\it c\'odigo do m\'etodo}@
  }
}

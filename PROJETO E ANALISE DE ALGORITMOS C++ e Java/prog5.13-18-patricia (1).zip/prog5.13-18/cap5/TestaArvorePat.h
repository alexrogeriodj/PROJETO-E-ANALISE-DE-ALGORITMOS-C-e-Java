#ifndef _TESTAARVOREPAT_H_
#define _TESTAARVOREPAT_H_
#include "ArvorePatricia.h" // @{\it vide Programa~\ref{c_5.16}}@
#include "../cap4/PermutacaoRandomica.h" // @{\it vide Programa~\ref{c_4.24}}@
#include<iostream>
using std::cout;
using std::endl;
using cap4::PermutacaoRandomica;
namespace cap5 {
  class TestaArvorePat {
  public:
   static void main ();
  };
  void TestaArvorePat::main () {
    ArvorePatricia *dicionario = new ArvorePatricia (8);
    int min = 32, max = 126;    
    int length = max-min+1;
    char *vetor = new char[length];
    for (int i = min; i <= max; i++)
      vetor[i-min] = (char)i;    

    // @{\it Gera uma permuta\c{c}\~ao aleat\'oria de chaves entre 0 e max-1}@
    PermutacaoRandomica::permut (vetor, length);
    
    // @{\it Insere cada chave na \'arvore}@
    for (int i = 0; i < length; i++) { 
      char c = vetor[i];
      dicionario->insere (c);
      cout << "Inseriu chave" << i << ": " << (int)c << " -- char:" << c << endl;
    }
    dicionario->imprime ();
    // @{\it Gera outra permuta\c{c}\~ao aleat\'oria de chaves}@
    PermutacaoRandomica::permut (vetor, length);

    // @{\it Pesquisa cada chave na \'arvore}@
    for (int i = 0; i < length; i++) {
      char c = vetor[i];
      cout << "Pesquisando chave" << i << ": " << c << endl;      
      dicionario->pesquisa (c);
    }    
    delete vetor;
    delete dicionario;
  }
}
#endif 

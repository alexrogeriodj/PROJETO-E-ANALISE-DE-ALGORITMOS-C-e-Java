#ifndef _ARVOREPATRICIA_H_
#define _ARVOREPATRICIA_H_
#include <typeinfo>
#include <string>
#include <iostream>
using std::cout;
using std::endl;
using std::string;
namespace cap5 {
  class ArvorePatricia {
  private:
    class PatNo {
    public: virtual ~PatNo() {};
    };
    class PatNoInt : public PatNo {
    friend class ArvorePatricia;
    private:
      int index; 
      PatNo *esq, *dir;      
    };  
    class PatNoExt : public PatNo {
    friend class ArvorePatricia;
    private:
      char chave; // @{\it O tipo da chave depende da aplica\c{c}\~ao}@
    };  
    PatNo *raiz;
    int nbitsChave;
    
    // @{\it Retorna o i-\'esimo bit da chave k a partir da esquerda}@
    int bit (int i, char k) const;
    // @{\it Verifica se p \'e n\'o externo}@
    bool eExterno (PatNo *p) const;
    PatNo *criaNoInt (int i, PatNo *esq, PatNo *dir) const;
    PatNo *criaNoExt (char k) const;
    void pesquisa (char k, PatNo *t) const;
    PatNo *insereEntre (char k, PatNo *t, int i) const;
    PatNo *insere (char k, PatNo *t);
    void central (PatNo *pai, PatNo *filho, string msg) const;
    void liberaMemoria (PatNo *p);
  public:
    void imprime () const;
    ArvorePatricia (int nbitsChave);
    void pesquisa (char k) const;
    void insere (char k);
    ~ArvorePatricia();
  };
  // @{\it Retorna o i-\'esimo bit da chave k a partir da esquerda}@
  int ArvorePatricia::bit (int i, char k) const {
    if (i == 0) return 0;
    int c = (int)k;
    for (int j = 1; j <= this->nbitsChave - i; j++) c = c/2;
    return c % 2;
  }
  // @{\it Verifica se p \'e n\'o externo}@
  bool ArvorePatricia::eExterno (PatNo *p) const {    
    return (strcmp(typeid(*p).name(), typeid(PatNoExt).name()) == 0);
  }            
  ArvorePatricia::PatNo *ArvorePatricia::
  criaNoInt (int i, PatNo *esq, PatNo *dir) const {
    PatNoInt *p = new PatNoInt ();
    p->index = i; p->esq = esq; p->dir = dir;
    return p;
  }
  ArvorePatricia::PatNo *ArvorePatricia::criaNoExt (char k) const {
    PatNoExt *p = new PatNoExt ();
    p->chave = k;
    return p;
  }    
  void ArvorePatricia::pesquisa (char k, PatNo *t) const {
    if (this->eExterno (t)) {
      PatNoExt *aux = (PatNoExt*)t;
      if (aux->chave == k) cout << "Elemento encontrado" << endl;
      else cout << "Elemento nao encontrado" << endl;
    }
    else { 
      PatNoInt *aux = (PatNoInt*)t;
      if (this->bit (aux->index, k) == 0) pesquisa (k, aux->esq);
      else pesquisa (k, aux->dir);
    }
  }
  
  ArvorePatricia::PatNo *ArvorePatricia::
  insereEntre (char k, PatNo *t, int i) const {
    PatNoInt *aux = NULL; 
    if (!this->eExterno (t)) aux = (PatNoInt*)t;
    if (this->eExterno (t) || (i < aux->index)) { // @{\it Cria um novo n\'o externo}@
      PatNo *p = this->criaNoExt (k);
      if (this->bit (i, k) == 1) return this->criaNoInt (i, t, p);
      else return this->criaNoInt (i, p, t);
    }
    else {
      if (this->bit (aux->index, k) == 1) 
        aux->dir = this->insereEntre (k, aux->dir, i);
      else aux->esq = this->insereEntre (k, aux->esq, i);
      return aux;
    }
  }

  ArvorePatricia::PatNo *ArvorePatricia::insere (char k, PatNo *t) {
    if (t == NULL) return this->criaNoExt (k);
    else {
      PatNo *p = t;
      while (!this->eExterno (p)) {
        PatNoInt *aux = (PatNoInt*)p;
        if(this->bit (aux->index, k) == 1) p = aux->dir; else p = aux->esq;
      }
      PatNoExt *aux = (PatNoExt*)p;
      int i = 1; // @{\it acha o primeiro bit diferente}@
      while ((i <= this->nbitsChave)&&
             (this->bit (i, k) == this->bit (i, aux->chave))) i++;
      if (i > this->nbitsChave) {
        cout << "Erro: chave ja esta na arvore" << endl; 
        return t;
      }
      else return this->insereEntre (k, t, i);
    }
  }
  void ArvorePatricia::central (PatNo *pai, PatNo *filho, string msg) const {
    if (filho != NULL) {
      if (!this->eExterno (filho)) {
        PatNoInt *aux = (PatNoInt*)filho; 
        central (filho, aux->esq, "ESQ");
        if (pai != NULL)
          cout << "Pai: " << ((PatNoInt*)pai)->index << " " << msg << " Int: " << aux->index << endl;
        else cout << "Pai: NULL " << msg << " Int: " << aux->index << endl;
        central (filho, aux->dir, "DIR");
      } else {
        PatNoExt *aux = (PatNoExt*)filho;
        if (pai != NULL)
          cout << "Pai: " << ((PatNoInt*)pai)->index << " " << msg << " Ext: " << aux->chave << endl;
        else cout << "Pai: NULL " << msg << " Ext: " << aux->chave << endl;
      }
    }
  }
  void ArvorePatricia::liberaMemoria (PatNo *p) {
    if (p == NULL) return;
    if (this->eExterno(p)) delete p;
    else {
      PatNoInt *aux = (PatNoInt *)p;
      liberaMemoria (aux->esq); liberaMemoria (aux->dir); delete p;
    }
  }
  
  void ArvorePatricia::imprime () const {
    this->central (NULL, this->raiz, "RAIZ");
  }
  ArvorePatricia::ArvorePatricia (int nbitsChave) {
    this->raiz = NULL; this->nbitsChave = nbitsChave; 
  }
  void ArvorePatricia::pesquisa (char k) const { 
    this->pesquisa (k, this->raiz); 
  }
  void ArvorePatricia::insere (char k) { 
    this->raiz = this->insere (k, this->raiz); 
  }         
  ArvorePatricia::~ArvorePatricia() {
    this->liberaMemoria (this->raiz);
  }
}

#endif 

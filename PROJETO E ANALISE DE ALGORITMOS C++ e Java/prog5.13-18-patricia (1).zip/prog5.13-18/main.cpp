#include "cap5/TestaArvorePat.h"

int main (int argc, char **argv) 
{
	cap5::TestaArvorePat::main ();
}

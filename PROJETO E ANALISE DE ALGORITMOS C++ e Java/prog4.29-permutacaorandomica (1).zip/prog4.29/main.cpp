#include "cap4/PermutacaoRandomica.h"

int main (int argc, char **argv) 
{
	cap4::PermutacaoRandomica::main ();
}

package cap1;
public class Conta {  
  private double saldo;
  public void alteraSaldo (double saldo) {
    this.saldo = saldo;
  }
}

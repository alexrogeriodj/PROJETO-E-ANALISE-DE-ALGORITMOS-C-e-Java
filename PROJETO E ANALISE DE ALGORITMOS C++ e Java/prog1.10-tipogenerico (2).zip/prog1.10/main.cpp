#include "cap1/tipogenerico/TestaLista.h"

int main (int argc, char **argv) 
{
	cap1_tipogenerico::TestaLista::main ();
}

#ifndef TESTALISTA_H_
#define TESTALISTA_H_
#include "Lista.h"
#include<sys/time.h>
#include<cstdlib>
#include<iostream>
using std::srand;
using std::cout;
using std::endl;
namespace cap1_tipogenerico {
	class TestaLista {
	public:
	  static void main ();
	};
	
	void TestaLista::main () { 
      struct timeval t;
	  gettimeofday (&t, 0);
	  srand ((unsigned int)t.tv_usec);
	  int vetor[1000], i, max = 10; 
	  Lista<int> lista; 
	  /*Gera uma permutacao aleatoria de chaves entre 0 e max-1*/
	  for (i = 0; i < max; i++) vetor[i] = i;
	  for (i = 0; i < max; i++) { 
		int k = rand () % max;
	    int j = rand () % max;
	    int n = vetor[k];
	    vetor[k] = vetor[j];
	    vetor[j] = n;
	  }  
	  try {
	    int item = 0;
	    /*Insere cada chave na lista */
	    for (i = 0; i < max; i++) { 
	  	  item = vetor[i];
	      lista.insere (item);
	      cout << "Inseriu: " << item << endl;
	    }
	    lista.imprime ();
	  	// Pesquisa cada chave da lista
	    for (i = 0; i < max; i++) {
	  	  int *itemPtr = lista.pesquisa (vetor[i]);
	  	  cout << "Item: " << *itemPtr << endl;
	    }
	    // Pesquisa sem sucesso
	    item = 100;
	    int *itemPtr = lista.pesquisa (item);
	    if (itemPtr == 0) cout << "Item nao encontrado" << endl;
	    /*Retira cada chave da lista */
	    for (i = 0; i < max; i++) { 
	      itemPtr = lista.retira(vetor[i]);
	      cout << "Retirou: " << *itemPtr << endl;
	      delete itemPtr;
	    } 
	    itemPtr = lista.retiraPrimeiro ();
	    delete itemPtr;
	  } catch (logic_error e) {
	    cout << e.what () << endl;  	
	  }
	  lista.imprime (); 
	}  	
}
#endif 


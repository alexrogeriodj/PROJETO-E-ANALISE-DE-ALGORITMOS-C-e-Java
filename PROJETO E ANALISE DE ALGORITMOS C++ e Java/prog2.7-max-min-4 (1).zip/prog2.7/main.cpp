#include "cap2/MaxMin4.h"

int main (int argc, char **argv) 
{
	cap2::MaxMin4::main ();
}

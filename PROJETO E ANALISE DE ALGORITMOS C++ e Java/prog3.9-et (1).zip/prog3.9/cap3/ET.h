#ifndef ET_H_
#define ET_H_
#include "arranjo/Pilha.h" // @{\it vide Programa~\ref{c_3.11}}@
#include<iostream>
using std::cout;
using std::cin;
using std::endl;
#define maxTam 70
#define cancelaCarater '#'
#define cancelaLinha '\\'
#define saltaLinha '*'
#define marcaEof '~'
using cap3_arranjo::Pilha; // @{\it vide Programa~\ref{c_3.11}}@
namespace cap3 {
	class ET {
	private: static void imprime (Pilha<char> *pilha);
	public:  static void main ();
	};
	void ET::imprime (Pilha<char> *pilha) {
	  Pilha<char> pilhaAux (maxTam); char *x;
	  while (!pilha->vazia ()) {
	    x = pilha->desempilha (); pilhaAux.empilha (*x); delete x;
	  }
	  while (!pilhaAux.vazia ()) {
	    x = pilhaAux.desempilha (); cout << *x; delete x;
	  } cout << endl;
	}
	void ET::main () {
	  Pilha<char> *pilha = new Pilha<char> (maxTam);
	  char *c = new char;    
	  try {
	    cin >> *c; if (*c == '\n') *c = ' ';
	    while (*c != marcaEof) {
	      if (*c == cancelaCarater) {
	        if (!pilha->vazia ()) {	delete c; c = pilha->desempilha (); }
	      }
	      else if (*c == cancelaLinha) {
	      	delete pilha; pilha = new Pilha<char> (maxTam);
	      }
	      else if (*c == saltaLinha) imprime (pilha);
	      else {
	        if (pilha->tamanho () == maxTam) imprime (pilha);
	        pilha->empilha (*c);
	      }
	      cin >> *c;
	      if (*c == '\n') *c = ' ';
	    }
	    if (!pilha->vazia ()) imprime (pilha);
	  } catch (logic_error e) { cout << e.what () << endl; }
	  delete pilha; delete c;
	}
}
#endif

#include "cap3/ET.h"

int main (int argc, char **argv) 
{
	cap3::ET::main ();
}

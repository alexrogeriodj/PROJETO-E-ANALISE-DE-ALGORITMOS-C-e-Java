1. Compilacao
  Nao gera nenhum programa executavel
  
-----------------------------------------------------

2. Execucao:
   2.1 Java: Nao possui executavel
   2.2 C++: Nao possui executavel
 
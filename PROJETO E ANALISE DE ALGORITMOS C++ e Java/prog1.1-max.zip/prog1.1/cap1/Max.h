#ifndef MAX_H_
#define MAX_H_
#include "Item.h"
namespace cap1 {
	template <class TipoChave> class Max { 
	public:
	  static int max (int v[], int n);
	  static Item<TipoChave> *max (Item<TipoChave>**v, int n);
	};
	template <class TipoChave>
	int Max<TipoChave>::max (int v[], int n) {
      int max = v[0];
      for (int i = 1; i < n; i++) if (max < v[i]) max = v[i];
      return max;
	}
	template <class TipoChave>
	Item<TipoChave>* Max<TipoChave>::max (Item<TipoChave> **v, int n) { 
      Item<TipoChave> *max = v[0];
      for (int i = 1; i < n; i++) if (max->compara (v[i]) < 0) max = v[i];
      return max;
	}
}
#endif

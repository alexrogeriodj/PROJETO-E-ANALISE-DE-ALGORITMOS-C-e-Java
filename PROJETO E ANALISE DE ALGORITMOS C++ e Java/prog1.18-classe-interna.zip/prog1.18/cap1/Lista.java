package cap1;
public class Lista {  
  // @{\it C\'odigo da classe Lista}@
  private class Celula {
    // @{\it C\'odigo da classe Celula}@
  }
}

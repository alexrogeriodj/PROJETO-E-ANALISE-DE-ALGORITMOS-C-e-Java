#ifndef ORDENACAOEXTERNA_H_
#define ORDENACAOEXTERNA_H_
#include <stdio.h>
namespace cap4_ordenacaoexterna {
	class OrdenacaoExterna {
	private:
	  int ordemIntercal;
	public:
		OrdenacaoExterna(int ordemIntercal);
	  void ordeneExterno ();		
	};	
	OrdenacaoExterna::OrdenacaoExterna(int ordemIntercal) {
	  this->ordemIntercal = ordemIntercal;
	}  		
	void OrdenacaoExterna::ordeneExterno () { 
	  int nBlocos = 0;
	  RandomAccessFile arqEntrada, arqSaida;
	  RandomAccessFile arrArqEnt[] = new RandomAccessFile[ordemIntercal];
	  short Fim;
	  int low, high, lim;
	  nBlocos = 0;
	  arqEntrada = abrir arquivo a ser ordenado;
	  do { // {\it Forma\c{c}\~ao inicial dos nBlocos ordenados}@
	    nBlocos++;
	    fim = enchePaginas (nBlocos, arqEntrada);
	    ordeneInterno;
	    arqSaida = abreArqSaida (nBlocos);
	    descarregaPaginas (arqSaida);
	    fechaArq (arqSaida); 
	  } while (!Fim);
	  fechaArq (arqEntrada);
	  low = 0;
	  high = nBlocos-1;
	  while (low < high) {// @{\it Intercala\c{c}\~ao dos nBlocos ordenados}@
	    lim = minimo (low + ordemIntercal-1, high);
	    abreArqEntrada (arrArqEnt, low, lim);
	    high++;
	    arqSaida = abreArqSaida (high);
	    intercale (arrArqEnt, low, lim, arqSaida);
	    fechaArq (arqSaida);
	    for (i= low; i < lim; i++) {
	      fechaArq (arrArqEnt[i]);
	      apague_Arquivo (arrArqEnt[i]);
	    }
	    low += ordemIntercal;
	  }
	  Mudar o nome do arquivo high para o nome fornecido pelo usuario;
	}		
}
#endif
package cap4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import cap4.ordenacaointerna.OrdenacaoParcial;

public class TestaOrdenacaoParcial {
  private static final int tam = 20;
  
  public static void copia (Item fonte[], Item destino[], int n) {
	  for (int i = 1; i <= n; i++)
		  destino[i] = fonte[i];
  }
  
  public static void testa (Item v[], int n, int k) {
    for (int i = 2; i <= k; i++) {
      if (v[i].compara (v[i - 1]) < 0) {
        System.out.print ("ERRO: ");
        imprime (v, n);
        return;
      }
    }
    System.out.print ("OK: ");
    imprime (v, n);
  }
  
  public static void imprime (Item v[], int n) {
	  for (int i = 1; i <= n; i++)
		  System.out.print (v[i].toString () + " ");
	  System.out.println ();
  }
  
  public static void main (String[] args) {
    MeuItem a[] = new MeuItem[tam + 1];
    MeuItem b[] = new MeuItem[tam + 1];
    BufferedReader in = new BufferedReader (new InputStreamReader (System.in));
    int n = 20, k = 0;
    for (int i = 1; i <= n; i++)
      a[i] = new MeuItem (i);
    PermutacaoRandomica.permut (a, n);
    copia (a, b, n);
    System.out.print ("Desordenado : ");
    imprime (a, n);
    try {
      System.out.print ("Valor de k = ");
      k = Integer.parseInt (in.readLine ());
    } catch (Exception e) {
      System.out.print (e.getMessage ());
    }
    System.out.println ("SelecaoParcial: ");
    OrdenacaoParcial.selecaoParcial (b, n, k);
    testa (b, n, k);
    copia (a, b, n);
    System.out.println ("InsercaoParcial: ");
    OrdenacaoParcial.insercaoParcial (b, n, k);
    testa (b, n, k);
    copia (a, b, n);
    System.out.println ("InsercaoParcial2: ");
    OrdenacaoParcial.insercaoParcial2 (b, n, k);
    testa (b, n, k);
    copia (a, b, n);
    System.out.println ("QuickSortParcial: ");
    OrdenacaoParcial.quicksortParcial (b, n, k);
    testa (b, n, k);
    copia (a, b, n);
    System.out.println ("HeapsortParcial: ");
    OrdenacaoParcial.heapsortParcial (b, n, k);
    System.out.println ("A parte ordenada esta no final do vetor:");
    imprime (b, n);
    copia (a, b, n);
    System.out.println ("DavisortParcial: ");
    OrdenacaoParcial.davisortParcial (b, n, k);
    testa (b, n, k);
  }
}

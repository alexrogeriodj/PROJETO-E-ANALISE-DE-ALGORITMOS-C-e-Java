1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
------------------------------------------------------------------------

2. Execucao:
   2.1 Java: 
       * Fila de prioridades: java cap4.TestaFPHeapMin 14 < testefp.txt
       * Ordenacao parcial: java cap4.TestaOrdenacaoParcial
   2.2 C++: 
       * Fila de prioridades: ./prog4.3-16-filaprioridades 14 < testefp.txt
       * Ordenacao parcial: ./prog4.17-22-ordenacaoparcial
 

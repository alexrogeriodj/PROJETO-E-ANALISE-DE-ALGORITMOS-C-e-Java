#include "cap1/B.h"

int main (int argc, char **argv) 
{
	cap1::B::main ();
}

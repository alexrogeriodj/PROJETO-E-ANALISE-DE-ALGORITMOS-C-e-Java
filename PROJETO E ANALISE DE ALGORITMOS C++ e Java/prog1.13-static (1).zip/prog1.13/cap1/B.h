#ifndef B_H_
#define B_H_
namespace cap1 {
	class A {
	public: 
	  static int total; 
	  int media;
	};	
	int A::total;
	
	class B {
	public:
	  static void main ();
	};
	void B::main () {
	  A a; a.total = 5; a.media = 5;
	  A b; b.total = 7; b.media = 7;
	}
}
#endif 

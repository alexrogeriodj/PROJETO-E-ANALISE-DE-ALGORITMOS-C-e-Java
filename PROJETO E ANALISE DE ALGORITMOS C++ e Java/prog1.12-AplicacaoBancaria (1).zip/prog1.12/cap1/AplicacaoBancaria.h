#ifndef APLICACAOBANCARIA_H_
#define APLICACAOBANCARIA_H_
#include<iostream>
using std::cout;
using std::endl;
namespace cap1 {
  class ContaBancaria {
  private: 
    double saldo;
  public:
    ContaBancaria (double saldoInicial);
    void deposito (double valor);
    void saque (double valor);
    void imprime () const;
    ~ContaBancaria () {}
  };
  
  ContaBancaria::ContaBancaria (double saldoInicial) {
    saldo = saldoInicial;
  }
  void ContaBancaria::deposito (double valor) {
    saldo = saldo + valor;
  }
  void ContaBancaria::saque (double valor) {
    saldo = saldo - valor;
  }
  void ContaBancaria::imprime () const {
    cout << "saldo=" << saldo << endl;
  }
  
  class AplicacaoBancaria {
  public: static void main ();
  };
  
  void AplicacaoBancaria::main () {
    ContaBancaria conta1(200.00);
    cout << "Antes da movimentacao, ";
    conta1.imprime ();
    conta1.deposito (50.00);
    conta1.saque (70.00);
    cout << "Depois da movimentacao, ";
    conta1.imprime ();
  }
}
#endif

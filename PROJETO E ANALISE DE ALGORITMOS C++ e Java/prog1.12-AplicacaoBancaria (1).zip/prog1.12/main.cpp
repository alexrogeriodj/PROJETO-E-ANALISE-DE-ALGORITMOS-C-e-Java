#include "cap1/AplicacaoBancaria.h"

int main (int argc, char **argv) 
{
	cap1::AplicacaoBancaria::main ();
}

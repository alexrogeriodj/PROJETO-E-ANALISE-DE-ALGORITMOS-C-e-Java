#include "cap1/Polimorfismo.h"

int main (int argc, char **argv) 
{
	cap1::Polimorfismo::main ();
}

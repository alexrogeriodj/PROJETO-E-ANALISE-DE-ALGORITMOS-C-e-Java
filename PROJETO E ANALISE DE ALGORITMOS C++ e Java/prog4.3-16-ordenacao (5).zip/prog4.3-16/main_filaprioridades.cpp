#include "cap4/TestaFPHeapMax.h"

int main (int argc, char **argv) 
{
	cap4::TestaFPHeapMax::main (argc, argv);
}

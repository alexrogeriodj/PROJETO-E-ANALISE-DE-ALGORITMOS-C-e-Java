1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
------------------------------------------------------------------------

2. Execucao:
   2.1 Java: 
       * Fila de prioridades: java cap4.TestaFPHeapMax 14 < testefp.txt 
       * Ordenacao: java cap4.TestaOrdenacao
   2.2 C++: 
       * Fila de prioridades: ./prog4.3-16-filaprioridades 14 < testefp.txt
       * Ordenacao: ./prog4.3-16-ordenacao
 

#include "cap4/TestaOrdenacao.h"

int main (int argc, char **argv) 
{
	cap4::TestaOrdenacao::main ();
}

package cap1;
public interface Item {
  public int compara (Item it);
}

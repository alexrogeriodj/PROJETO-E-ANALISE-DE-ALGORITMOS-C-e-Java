#include "cap2/Ordenacao.h"

int main (int argc, char **argv) 
{
	cap2::Ordenacao::main ();
}

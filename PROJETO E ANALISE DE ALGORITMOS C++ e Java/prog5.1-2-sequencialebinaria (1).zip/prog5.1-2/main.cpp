#include "cap5/TestaTabela.h"
int main (int argc, char **argv) {
  cap5::TestaTabela::main ();  
  return 0; 
}


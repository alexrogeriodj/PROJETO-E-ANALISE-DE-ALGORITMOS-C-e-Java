#ifndef PAINELDECONTROLE_H_
#define PAINELDECONTROLE_H_
namespace cap1 {
	class PainelDeControle {
	private:
	  float temperaturaCorrente;
	  float temperaturaDesejada;
	public:
	  void ligaForno ();
	  void desligaForno ();
	};
	void PainelDeControle::ligaForno () {
  	  // @{\it c\'odigo do m\'etodo}@
	}
	void PainelDeControle::desligaForno () {
      // @{\it c\'odigo do m\'etodo}@
	}	
}
#endif

#ifndef ARVOREBINARIA_H_
#define ARVOREBINARIA_H_
#include "../cap4/Item.h" // @{\it vide Programa~\ref{c_4.0}}@
#include<iostream>
using std::cout;
using std::endl;
using namespace cap4;
namespace cap2 {
	template <class TipoChave> class ArvoreBinaria {
	private:
		class No {
		friend class ArvoreBinaria<TipoChave>;
		private:
	  	Item<TipoChave> *reg; No esq, dir; 
	  	No () { reg = 0;} ~No () { if (reg != 0) delete reg;}
		};
    No *raiz;
    void ArvoreBinaria::central (No *p) const; // @{\it vide Programa~\ref{c_2.2}}@ 
	};
	template <class TipoChave>	
  void ArvoreBinaria<TipoChave>::central (No *p) const {
    if (p != NULL) {
      central (p->esq);
      cout << p->reg->toString() << endl;
      central (p->dir);
    }
	}
}
#endif 

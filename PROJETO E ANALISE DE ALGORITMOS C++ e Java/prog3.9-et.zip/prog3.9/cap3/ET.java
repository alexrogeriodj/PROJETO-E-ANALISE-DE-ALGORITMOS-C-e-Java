package cap3; 
import cap3.arranjo.Pilha; // @ {\it vide Programa~\ref{Fig2.2.2}}@
public class ET {
  private class Definicoes {
    public static final int  maxTam         = 70;
    public static final char cancelaCarater = '#';
    public static final char cancelaLinha   = '\\';
    public static final char saltaLinha     = '*';
    public static final char marcaEof       = '~';
  }
  private static void imprime (Pilha pilha) throws Exception {
    Pilha pilhaAux = new Pilha (Definicoes.maxTam);
    Character x;
    while (!pilha.vazia ()) {
      x = (Character) pilha.desempilha (); pilhaAux.empilha (x);
    }
    while (!pilhaAux.vazia ()) {
      x = (Character) pilhaAux.desempilha (); System.out.print (x);
    }
    System.out.print ('\n');
  }
  public static void main (String[] args) {
    Pilha pilha = new Pilha (Definicoes.maxTam);
    try {
      char c = (char) System.in.read (); 
      Character x = new Character (c);
      if (x.charValue () == '\n') x = new Character (' ');
      while (x.charValue () != Definicoes.marcaEof) {
        if (x.charValue () == Definicoes.cancelaCarater) {
          if (!pilha.vazia ()) x = (Character) pilha.desempilha ();
        }
        else if (x.charValue () == Definicoes.cancelaLinha)
          pilha = new Pilha (Definicoes.maxTam);
        else if (x.charValue () == Definicoes.saltaLinha) 
          imprime (pilha);
        else {
          if (pilha.tamanho () == Definicoes.maxTam) imprime (pilha);
          pilha.empilha (x);
        }
        c = (char) System.in.read (); x = new Character (c);
        if (x.charValue () == '\n') x = new Character (' ');
      }
      if (!pilha.vazia ()) imprime (pilha);
    } catch (Exception e) { System.out.println (e.getMessage ()); }
  }
}
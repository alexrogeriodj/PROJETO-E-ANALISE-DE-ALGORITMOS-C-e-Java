1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
-----------------------------------------------------

2. Execucao:
   2.1 Java: java cap3.Vestibular < vestibular.dat
   2.2 C++: ./prog3.6 < vestibular.dat
 
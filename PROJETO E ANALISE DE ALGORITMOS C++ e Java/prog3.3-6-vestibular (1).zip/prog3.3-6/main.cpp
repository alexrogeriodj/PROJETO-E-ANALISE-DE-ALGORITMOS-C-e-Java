#include "cap3/Vestibular.h"

int main (int argc, char **argv) 
{
	cap3::Vestibular::main ();
}

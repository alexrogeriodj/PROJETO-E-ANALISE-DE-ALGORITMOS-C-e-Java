#include "cap5/TestaTabelaHash.h"

int main (int argc, char **argv) 
{
	cap5::TestaTabelaHash::main ();
}

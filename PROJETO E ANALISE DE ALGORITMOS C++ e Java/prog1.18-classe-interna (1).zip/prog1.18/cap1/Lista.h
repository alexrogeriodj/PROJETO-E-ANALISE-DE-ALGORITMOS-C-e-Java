#ifndef LISTA_H_
#define LISTA_H_
namespace cap1 {
  class Lista {  
    // @{\it C\'odigo da classe Lista}@
  private:
    class Celula {
      // @{\it C\'odigo da classe Celula}@
    };
  };
}
#endif

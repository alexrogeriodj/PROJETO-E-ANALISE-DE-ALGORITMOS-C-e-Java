#include "cap1/MaxMin2.h"

int main (int argc, char **argv) 
{
	cap1::MaxMin2::main ();
}

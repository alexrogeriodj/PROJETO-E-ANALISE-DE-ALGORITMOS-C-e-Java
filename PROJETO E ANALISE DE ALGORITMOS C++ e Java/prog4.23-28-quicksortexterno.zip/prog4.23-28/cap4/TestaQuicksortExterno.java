package cap4;
import java.io.RandomAccessFile;
import cap4.ordenacaoexterna.QuicksortExterno; // @{\it vide Programa~\ref{prog:classequicksortexterno}}@
public class TestaQuicksortExterno {
  public static void main (String[] args) {
    try {
      RandomAccessFile arq = new RandomAccessFile ("qe.dat", "rwd");
      MeuItem item = new MeuItem (5); item.gravaArq (arq);
      item = new MeuItem (3); item.gravaArq (arq);
      item = new MeuItem (10); item.gravaArq (arq);
      item = new MeuItem (6); item.gravaArq (arq);
      item = new MeuItem (1); item.gravaArq (arq);
      item = new MeuItem (7); item.gravaArq (arq);
      item = new MeuItem (4); item.gravaArq (arq);
      arq.close ();
      QuicksortExterno quicksortExterno = new QuicksortExterno ("qe.dat", 3);
      quicksortExterno.quicksortExterno (1, 7);
      quicksortExterno.fechaArquivos ();
      arq = new RandomAccessFile ("qe.dat", "r");
      item.leArq (arq);
      while (arq.getFilePointer () < arq.length ()) {
        System.out.println ("Registro=" + item.toString ());
        item.leArq (arq);
      }
      System.out.println ("Registro=" + item.toString ()); arq.close ();  
    } catch (Exception e) { System.out.println (e.getMessage ()); }
  }
}

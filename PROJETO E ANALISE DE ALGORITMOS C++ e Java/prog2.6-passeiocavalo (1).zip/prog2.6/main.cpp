#include "cap2/PasseioCavalo.h"

int main (int argc, char **argv) 
{
	cap2::PasseioCavalo::main ();
}

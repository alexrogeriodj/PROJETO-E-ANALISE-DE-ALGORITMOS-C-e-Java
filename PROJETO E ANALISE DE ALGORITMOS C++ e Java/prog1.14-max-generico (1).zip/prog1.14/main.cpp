#include "cap1/EncontraMax.h"

int main (int argc, char **argv) 
{
	cap1::EncontraMax::main ();
}

#ifndef ENCONTRAMAX_H_
#define ENCONTRAMAX_H_
#include "Item.h" // @{\it Vide Programa~\ref{prog:interfaceitemcap1c}}@
#include "MeuItem.h" // @{\it Vide Programa~\ref{prog:tipoitemcap1c}}@
#include "Max.h" // @{\it Vide Programa~\ref{prog:maximoc}}@
#include<iostream>
using std::cout;
using std::endl;
namespace cap1 {
	class EncontraMax {  
  	public:
      static void main ();
  	};
  	void EncontraMax::main () {
      Item<int> **itens = new Item<int>*[2]; 
      itens[0] = new MeuItem (3); itens[1] = new MeuItem (10);
      Item<int> *max = Max<int>::max (itens, 2);
      cout << "Maior chave: " << ((MeuItem*)max)->chave << endl;
      for(int i = 0; i < 2; i++) delete itens[i];
      delete []itens;
  	}
}
#endif

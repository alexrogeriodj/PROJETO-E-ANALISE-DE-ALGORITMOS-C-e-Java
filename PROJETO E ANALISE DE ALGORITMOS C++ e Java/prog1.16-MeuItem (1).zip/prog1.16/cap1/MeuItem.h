#ifndef MEUITEM_H_
#define MEUITEM_H_
#include "Item.h" // @{\it Vide Programa~\ref{prog:interfaceitemcap1c}}@
namespace cap1 {
	class MeuItem : public Item<int> {
	public:
	  int chave; 
	  MeuItem (int chave);
	  virtual int compara (const Item<int> *item) const;
	  ~MeuItem () {}
	};
	MeuItem::MeuItem (int chave) { this->chave = chave; }
	int MeuItem::compara (const Item<int> *item) const {
	  MeuItem *it = (MeuItem *)item; 	
	  if (this->chave < it->chave) return -1;
	  else if (this->chave > it->chave) return 1;
	  return 0;
	}
}
#endif

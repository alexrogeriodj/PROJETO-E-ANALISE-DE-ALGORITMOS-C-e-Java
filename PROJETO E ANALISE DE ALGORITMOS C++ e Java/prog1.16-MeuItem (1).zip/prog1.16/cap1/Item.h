#ifndef ITEM_H_
#define ITEM_H_
namespace cap1 {
	template <class TipoChave> class Item {
	public:
	  virtual int compara (const Item<TipoChave> *it) const = 0;
	  virtual ~Item () {};
	};
}
#endif

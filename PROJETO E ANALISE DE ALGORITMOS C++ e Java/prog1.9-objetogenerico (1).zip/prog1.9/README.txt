1. Compilacao
  Basta digira make tanto para Java. Nao existe um 
  programa equivalente em C++.
  
-----------------------------------------------------

2. Execucao:
   2.1 Java: java cap1.objetogenerico.TestaLista
   2.2 C++: Nao existe equivalente
 
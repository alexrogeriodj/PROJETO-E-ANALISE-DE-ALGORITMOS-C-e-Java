#include "cap2/AvaliaMultMatrizes.h"

int main (int argc, char **argv) 
{
	cap2::AvaliaMultMatrizes::main (argc, argv);
}

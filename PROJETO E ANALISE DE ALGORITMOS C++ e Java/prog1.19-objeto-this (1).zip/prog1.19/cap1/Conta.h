#ifndef CONTA_H_
#define CONTA_H_
namespace cap1 {
	class Conta {  
	private: double saldo;
	public:  void alteraSaldo (double saldo);
	};
	void Conta::alteraSaldo (double saldo) { this->saldo = saldo; }
}
#endif

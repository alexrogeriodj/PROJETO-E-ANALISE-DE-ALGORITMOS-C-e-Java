#include "cap2/Fibonacci.h"

int main (int argc, char **argv) 
{
	cap2::Fibonacci::main ();
}

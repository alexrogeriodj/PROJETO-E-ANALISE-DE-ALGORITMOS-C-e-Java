package cap1;
public class Ordenacao {
  public static void ordena (int v[], int n) {
    for (int i = 0; i < n - 1; i++) {
      int min = i;
      for (int j = i + 1; j < n; j++)
        if (v[j] < v[min]) 
          min = j;
      /* @{\it Troca v[min] e v[i]}@ */
      int x = v[min]; 
      v[min] = v[i]; 
      v[i] = x;
    }
  }
  public static void main (String[] args) {
    int v[] = new int[10];
    v[0] = 5;  v[1] = 12;
    v[2] = 4;  v[3] = 1;
    v[4] = 9; v[5] = 22;
    v[6] = 3; v[7] = 11;
    v[8] = 17; v[9] = 33;
    Ordenacao.ordena (v, 10);
    for (int i = 0; i < 10; i++)
      System.out.println ("v[" + i +"]: " + v[i]);
  }
}

1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
-----------------------------------------------------

2. Execucao:
   2.1 Java: java cap3.TestaPilha
   2.2 C++: ./prog3.8
 
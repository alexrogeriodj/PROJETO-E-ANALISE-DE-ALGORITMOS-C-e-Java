#include "cap3/TestaPilha.h"

int main (int argc, char **argv) {	
  cap3::TestaPilha::main () ; 
  return 0; 
}


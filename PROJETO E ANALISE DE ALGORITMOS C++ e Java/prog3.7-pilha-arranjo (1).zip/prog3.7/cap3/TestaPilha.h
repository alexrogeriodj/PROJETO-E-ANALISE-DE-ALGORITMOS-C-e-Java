#ifndef TESTAPILHA_H_
#define TESTAPILHA_H_
#include "arranjo/Pilha.h"
//#include "autoreferencia/Pilha.h"
#include<sys/time.h>
#include<cstdlib>
#include<iostream>
using std::srand;
using std::cout;
using std::endl;
using cap3_arranjo::Pilha;
//using cap3_autoreferencia::Pilha;
namespace cap3 {
	class TestaPilha {
	public:
	  static void main ();
	};
	
	void TestaPilha::main () {
	  struct timeval t;
	  gettimeofday (&t, 0);
	  srand ((unsigned int)t.tv_usec);
	  int vetor[1000], i, max = 10; 
	  Pilha<int> pilha;
	  /*Gera uma permutacao aleatoria de chaves entre 0 e max-1*/
	  for (i = 0; i < max; i++) vetor[i] = i;
	  for (i = 0; i < max; i++) { 
		  int k = rand () % max;
	    int j = rand () % max;
	    int n = vetor[k];
	    vetor[k] = vetor[j];
	    vetor[j] = n;
	  }
	  try {
	    int item = 0;
	    /*Insere cada item na pilha */
	    for (i = 0; i < max; i++) { 
	  	  item = vetor[i];
	  	  pilha.empilha (item);
	      cout << "Empilhou: " << item << endl;
	    }
	    cout << "Tamanho da pilha: " << pilha.tamanho () << endl;
	    /*Desempilha cada chave */
	    int *itemPtr = 0;
	    for (i = 0; i < max; i++) {
	      itemPtr = pilha.desempilha ();
	      cout << "Desempilhou: " << *itemPtr << endl;
	      delete itemPtr;
	    }
	    itemPtr = pilha.desempilha ();
	    delete itemPtr;
	    cout << "Tamanho da pilha: " << pilha.tamanho () << endl;
	  } catch (logic_error e) {
	    cout << e.what () << endl;  	
	  }
	}  	
}
#endif 


#include "cap1/Ordenacao.h"

int main (int argc, char **argv) 
{
	cap1::Ordenacao::main ();
}

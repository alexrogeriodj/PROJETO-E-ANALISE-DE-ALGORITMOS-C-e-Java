#include "cap1/MaxMin1.h"

int main (int argc, char **argv) 
{
	cap1::MaxMin1::main ();
}

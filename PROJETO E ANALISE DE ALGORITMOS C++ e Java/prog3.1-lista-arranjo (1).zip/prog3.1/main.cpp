/** Cap 3. **/
#include "cap3/TestaLista.h"

int main (int argc, char **argv) {	
  cap3::TestaLista::main (); 
  return 0; 
}


#ifndef TESTAFILA_H_
#define TESTAFILA_H_
#include "arranjo/Fila.h"
#include<sys/time.h>
#include<cstdlib>
#include<iostream>
using std::srand;
using std::cout;
using std::endl;
using cap3_arranjo::Fila;
namespace cap3 {
	class TestaFila {
	public:
	  static void main ();
	};
	
	void TestaFila::main () {
		struct timeval t;
	  gettimeofday (&t, 0);
	  srand ((unsigned int)t.tv_usec);
	  int vetor[1000], i, max = 10; 
	  Fila<int> fila; 
	  /*Gera uma permutacao aleatoria de chaves entre 0 e max-1*/
	  for (i = 0; i < max; i++) vetor[i] = i;
	  for (i = 0; i < max; i++) { 
		  int k = rand () % max;
	    int j = rand () % max;
	    int n = vetor[k];
	    vetor[k] = vetor[j];
	    vetor[j] = n;
	  }  
	  try {
	    int item = 0;
	    /*Enfileira  cada chave  */
	    for (i = 0; i < max; i++) { 
	  	  item = vetor[i];
	  	  fila.enfileira (item);
	      cout << "Enfileirou: " << item << endl;
	    }
	    fila.imprime ();
	    /*Desenfileira cada chave */
	    int *itemPtr = 0;
	    for (i = 0; i < max; i++) {
	      itemPtr = fila.desenfileira ();
	      cout << "Desenfileirou: " << *itemPtr << endl;
	      delete itemPtr;
	    }
	    itemPtr = fila.desenfileira ();
	    delete itemPtr;
	  } catch (logic_error e) {
	    cout << e.what () << endl;  	
	  }
	  fila.imprime (); 
	}  	
}
#endif 


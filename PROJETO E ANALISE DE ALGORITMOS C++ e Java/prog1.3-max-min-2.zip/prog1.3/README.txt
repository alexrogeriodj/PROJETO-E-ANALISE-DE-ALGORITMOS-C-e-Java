1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
-----------------------------------------------------

2. Execucao:
   2.1 Java: java cap1.MaxMin2
   2.2 C++: ./prog1.3
 
package cap1;
public class Divisao {
/*  void met(int a, int b) throws Exception {
    // @{\it Dispara uma exce\c{c}\~ao que n\~ao \'e tratada localmente e deve ser repassada}@ 
    // @{\it para o local de tratamento por meio do comando throws.}@
    if (b == 0) throw new Exception("Divisao por zero");
    int dab = a/b; 
    try {
      int dba = b/a;
      System.out.println ("a/b = " + dab); 
      System.out.println ("b/a = " + dba);
      int vet[] = null; 
      vet[0] = 3; // @{\it Erro: acesso a mem\'oria n\~ao alocada}@
    } catch (ArithmeticException e) { // @{\it Captura um erro aritm\'etico}@
      System.out.println("Erro aritmetico:" + e.getMessage());
    }
    catch (Throwable e) { // @{\it Captura todas as outras exce\c{c}\~oes}@
      System.out.println("Erro geral");
    } finally { System.out.println ("Mensagem sempre exibida"); }    
  }
*/  
  
/*  int divisao (int a, int b) {
    try {
      if (b == 0) throw new Exception ("Divisao por zero");
      return (a/b);
    }
    catch (Exception objeto) {
      System.out.println ("Erro:" + objeto.getMessage());
      return (0);
    }
  }
*/
  int divisao (int a, int b) throws Exception {
    if (b == 0) throw new Exception ("Divisao por zero");
    return (a/b);
  }
  public static void main (String[] args) {
    Divisao d = new Divisao();
    try {
      d.divisao(3,0);
    } catch (Exception objeto) {
      System.out.println("Erro:" + objeto.getMessage());
    }
  }
}

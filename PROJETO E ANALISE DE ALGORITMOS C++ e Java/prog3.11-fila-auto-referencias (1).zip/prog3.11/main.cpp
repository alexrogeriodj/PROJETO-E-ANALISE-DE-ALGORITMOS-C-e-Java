#include "cap3/TestaFila.h"

int main (int argc, char **argv) 
{
	cap3::TestaFila::main ();
}

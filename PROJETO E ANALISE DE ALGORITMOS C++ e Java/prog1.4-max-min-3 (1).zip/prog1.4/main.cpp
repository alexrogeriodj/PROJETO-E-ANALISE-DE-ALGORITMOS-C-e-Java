#include "cap1/MaxMin3.h"

int main (int argc, char **argv) 
{
	cap1::MaxMin3::main ();
}

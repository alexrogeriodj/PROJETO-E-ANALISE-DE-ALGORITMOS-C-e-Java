#include "cap4/TestaQuicksortExterno.h"

int main (int argc, char **argv) 
{
	cap4::TestaQuicksortExterno::main ();
}

1. Compilacao
  Basta digira make tanto para Java quanto para C++.
  
------------------------------------------------------------------------

2. Execucao:
   2.1 Java: java cap4.TestaQuicksortExterno
   2.2 C++: ./prog4.23-28
 

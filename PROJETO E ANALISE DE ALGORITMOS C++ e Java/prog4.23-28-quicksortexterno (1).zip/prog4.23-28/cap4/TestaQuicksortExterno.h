#ifndef TESTAQUICKSORTEXTERNO_H_
#define TESTAQUICKSORTEXTERNO_H_
#include "ordenacaoexterna/QuicksortExterno.h" // @{\it vide Programa~\ref{c_4.200}}@
#include<iostream>
using std::cout;
using std::endl;
using cap4_ordenacaoexterna::QuicksortExterno; // @{\it vide Programa~\ref{c_4.200}}@
namespace cap4 {
	class TestaQuicksortExterno {
	public:
	  static void main ();
	};
	void TestaQuicksortExterno::main () {
		try {
			FILE *arq = fopen ("qe.dat", "wb"); 	
	    if (arq == 0) {
	      cout << "Arquivo nao pode ser aberto" << endl;
	      exit (1);
	    }
      MeuItem item (5);      item.gravaArq (arq);
      item.alteraChave (3);  item.gravaArq (arq);
      item.alteraChave (10); item.gravaArq (arq);
      item.alteraChave (6);  item.gravaArq (arq);
      item.alteraChave (1);  item.gravaArq (arq);
      item.alteraChave (7);  item.gravaArq (arq);
      item.alteraChave (4);  item.gravaArq (arq);
//      MeuItem item (2);      item.gravaArq (arq);
//      item.alteraChave (3);  item.gravaArq (arq);
//      item.alteraChave (6); item.gravaArq (arq);
//      item.alteraChave (1);  item.gravaArq (arq);
//      item.alteraChave (5);  item.gravaArq (arq);
//      item.alteraChave (4);  item.gravaArq (arq);
//      item.alteraChave (7);  item.gravaArq (arq);
	    fclose (arq);
	    QuicksortExterno quicksortExterno ("qe.dat", 3);
	    quicksortExterno.quicksortExterno (1, 7);
	    quicksortExterno.fechaArquivos ();
	    arq = fopen ("qe.dat", "rb");
	    if (arq == 0) {
	      cout << "Arquivo nao pode ser aberto" << endl;
	      exit (1);
	    }
	    item.leArq (arq);
	    while (!feof (arq)) {
	      cout << "Registro=" << item.toString () << endl;
	      item.leArq (arq);
	    }
	    fclose (arq);
	  } catch (logic_error e) {
	    cout << e.what () << endl;  	
	  }
	}
}
#endif 

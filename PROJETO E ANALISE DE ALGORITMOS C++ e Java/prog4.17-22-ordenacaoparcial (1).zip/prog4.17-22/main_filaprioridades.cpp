#include "cap4/TestaFPHeapMin.h"

int main (int argc, char **argv) 
{
	cap4::TestaFPHeapMin::main (argc, argv);
}

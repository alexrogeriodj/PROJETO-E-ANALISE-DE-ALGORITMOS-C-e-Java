#include "cap4/TestaOrdenacaoParcial.h"

int main (int argc, char **argv) 
{
	cap4::TestaOrdenacaoParcial::main ();
}

package cap1;
class Empregado {
  protected float salario;
  public float salarioMensal () { return salario; }
  public void imprime () { System.out.println ("Empregado"); }
}
class Secretaria extends Empregado {
  private int velocidadeDeDigitacao;
  public void imprime () { System.out.println ("Secretaria"); }
}
class Gerente extends Empregado {
  private float bonus;
  public float salarioMensal () { return salario + bonus; }
  public float salarioMensal (float desconto) { 
    return salario + bonus - desconto; 
  }
  public void imprime () { System.out.println ("Gerente"); }
}
public class Polimorfismo {
  public static void main (String[] args) {
    Empregado empregado = new Empregado ();
    Empregado secretaria = new Secretaria ();
    Empregado gerente = new Gerente ();
    empregado.imprime (); secretaria.imprime (); gerente.imprime ();
  }
}

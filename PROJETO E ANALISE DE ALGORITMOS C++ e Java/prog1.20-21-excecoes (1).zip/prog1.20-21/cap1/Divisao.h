#ifndef DIVISAO_H_
#define DIVISAO_H_
#include <stdexcept> 
using std::logic_error;
#include<iostream>
using std::cout;
using std::endl;

namespace cap1 {
	class Divisao {
	public:
	  int divisao (int a, int b) const;
//	  int divisao (int a, int b) const throw ( logic_error );
	  static void main ();
	}; 
	  
	int Divisao::divisao (int a, int b) const {
	  try {
	    if (b == 0) throw logic_error ("Divisao por zero");
	    return (a/b);
	  }
	  catch (logic_error objeto) {
	    cout << "Erro:" << objeto.what () << endl;
	    return (0);
	  }
	}
/*
	int Divisao::divisao (int a, int b) const throw ( logic_error ) {
	  if (b == 0) throw logic_error ("Divisao por zero");
	  return (a/b);
	}
*/  
	void Divisao::main () { 
	  Divisao* d = new Divisao();
	  try {
	    d->divisao(3,0);
	  } catch (logic_error objeto) {
	    cout << "Erro:" << objeto.what () << endl;
	  }
	  delete d;
	}
}
#endif

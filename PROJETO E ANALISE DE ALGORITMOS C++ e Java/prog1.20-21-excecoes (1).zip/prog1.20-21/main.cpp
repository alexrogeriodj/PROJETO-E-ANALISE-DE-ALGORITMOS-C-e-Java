#include "cap1/Divisao.h"

int main (int argc, char **argv) 
{
	cap1::Divisao::main ();
}

#ifndef _TESTATABELAHASH_H_
#define _TESTATABELAHASH_H_
#include "listaenc/TabelaHash.h" // @{\it vide Programa~\ref{c_5.24}}@
#include <iostream>
using std::cout;
using std::endl;
using std::cin;
using cap5_listaenc::TabelaHash;
namespace cap5 {
  class TestaTabelaHash {
  public:
    static void main ();    
  };
  
  void TestaTabelaHash::main () {
    TabelaHash<string> *tabela = new TabelaHash<string> (7, 7);
    cout << "Inserindo algumas chaves:" << endl;
    cout << "  Chave:";
    string chave; cin >> chave;
    while (chave != "aaaaaa") {
      tabela->insere (chave, chave);
      cout << "  Chave:"; cin >> chave;
    }
    cout << "Tabela apos insercao:" << endl;
    tabela->imprime ();

    cout << "Pesquisar:"; cin >> chave;
    while (chave != "aaaaaa") {
      string *obj = tabela->pesquisa (chave);
      if (obj == NULL)
        cout << "pesquisa sem sucesso" << endl;
      else cout << "sucesso" << endl;
      cout << "Pesquisar:"; cin >> chave;    
    }

    cout << "Retirar seguintes chaves:" << endl;
    cout << "  Chave:"; cin >> chave;
    while (chave != "aaaaaa") {
      tabela->retira (chave);
      cout << "  Chave:"; cin >> chave;
    }

    cout << "Tabela apos retiradas:" << endl;
    tabela->imprime ();

    cout << "Pesquisar:"; cin >> chave;
    while (chave != "aaaaaa") {
      string *obj = tabela->pesquisa (chave);
      if (obj == NULL)
        cout << "pesquisa sem sucesso" << endl;
      else cout << "sucesso" << endl;
      cout << "Pesquisar:"; cin >> chave;
    }

    cout << "Inserir de novo os elementos seguintes:" << endl;
    cout << "  Chave:"; cin >> chave;
    while (chave != "aaaaaa") {
      tabela->insere (chave, chave);
      cout << "  Chave:"; cin >> chave;
    }

    cout << "Tabela apos novas insercoes:\n" << endl;
    tabela->imprime ();
    delete tabela;
  }
}

#endif
